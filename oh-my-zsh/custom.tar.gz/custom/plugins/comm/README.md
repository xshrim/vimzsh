oh-my-zsh的完整主题插件,放置于oh-my-zsh的plugin目录下.
并在.zshrc文件中添加export ZSH=$HOME/.oh-my-zsh和plugins=(comm)两行以应用主题.
commg包含git-prompt支持,但会导致轻微卡顿
